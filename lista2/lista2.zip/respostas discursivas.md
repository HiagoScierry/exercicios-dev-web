1.A) ELEMENT ESTA APONTANDO PARA A TAG HEAD
1.B) O script ta sendo carregado antes do body da pagina  por isso não encontra nenhuma tag h1
1.C) esta referencia é o primeiro elemento da variavel outroelemento, que é um valor ja null. Assim não executando o alert posterior parando a execução da função